#include "stm32f407xx_gpio_driver.h"
void delay(void)
{
	for(uint32_t i=0;i<50000000;i++)
}
int main(void)
{
	GPIO_Handle_t GpioLed;
	GpioLed.pGPIOx=GPIOD;
	GpioLed.GPIO_Config.GPIO_PinNumber = GPIO_PIN_NO_15;
	GpioLed.GPIO_Config.GPIO_PinMode = GPIO_MODE_OUT;
	GpioLed.GPIO_Config.GPIO_PinSpeed = SPEED_MED;
	GpioLed.GPIO_Config.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioLed.GPIO_Config.GPIO_PinPinPupControl = GPIO_NO_PUPD;

	GPIO_Handle_t GpioL;
	GpioL.pGPIOx=GPIOD;
	GpioL.GPIO_Config.GPIO_PinNumber = GPIO_PIN_NO_13;
	GpioL.GPIO_Config.GPIO_PinMode = GPIO_MODE_OUT;
	GpioL.GPIO_Config.GPIO_PinSpeed = SPEED_MED;
	GpioL.GPIO_Config.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioL.GPIO_Config.GPIO_PinPinPupControl = GPIO_NO_PUPD;

	GPIO_Handle_t GpioE;
	GpioE.pGPIOx=GPIOD;
	GpioE.GPIO_Config.GPIO_PinNumber = GPIO_PIN_NO_13;
	GpioE.GPIO_Config.GPIO_PinMode = GPIO_MODE_OUT;
	GpioE.GPIO_Config.GPIO_PinSpeed = SPEED_MED;
	GpioE.GPIO_Config.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioE.GPIO_Config.GPIO_PinPinPupControl = GPIO_NO_PUPD;

	GPIO_Handle_t GpioLe;
	GpioLe.pGPIOx=GPIOD;
	GpioLe.GPIO_Config.GPIO_PinNumber = GPIO_PIN_NO_13;
	GpioLe.GPIO_Config.GPIO_PinMode = GPIO_MODE_OUT;
	GpioLe.GPIO_Config.GPIO_PinSpeed = SPEED_MED;
	GpioLe.GPIO_Config.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioLe.GPIO_Config.GPIO_PinPinPupControl = GPIO_NO_PUPD;

	GPIO_PeriClockControl(GPIOD, ENABLE);
	GPIO_PeriClockControl(GPIOD, ENABLE);
	GPIO_PeriClockControl(GPIOD, ENABLE);
	GPIO_Init(&GpioLed);
	GPIO_Init(&GpioL);
	GPIO_Init(&GpioLe);
	GPIO_Init(&GpioE);

	while(1)
	{
		GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_12);
		GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_13);
		GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_14);
		GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_15);
		delay();

	}
	return 0;
